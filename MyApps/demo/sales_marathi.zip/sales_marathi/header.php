<html>       		<head>
			<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
</html>
	    <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>                    </a>
                    <a class="brand" href="#">  
                  </a>
				 
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="brand">	<font size="3" > <?php echo date(" D, d M Y");?>   </font> </li>
							<li class="dropdown">
                    
				   <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> Wel Come <i class="caret"></i>

                              </a>
                                <ul class="dropdown-menu"> 
                                    <li>
                                        <a tabindex="1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
					
                          
                <li class="brand"><font  size="+3" color="#993333">  <?php include('name.php'); ?> </font></li><li class="brand"><marquee behavior="slide" scrollamount="3" direction=""><font size="3"> <?php echo"$comp_add"; ?></font></marquee></li>
						   
						     </ul> 
                                    
                             
                    </div>
                    <!--/.nav-collapse -->
              </div>
            </div>
        </div>
