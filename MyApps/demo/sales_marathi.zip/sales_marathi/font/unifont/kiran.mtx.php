<?php
$name='Kiran';
$type='TTF';
$desc=array (
  'Ascent' => 692,
  'Descent' => -200,
  'CapHeight' => 692,
  'Flags' => 4,
  'FontBBox' => '[-367 -219 730 753]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-100;
$ut=50;
$ttffile='C:\wamp\www\stock management/font/unifont/Kiran.ttf';
$originalsize=37028;
$fontkey='kiran';
?>