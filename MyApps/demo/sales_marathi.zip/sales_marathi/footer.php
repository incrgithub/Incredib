<footer>
                <p align="center">All rights reserved &copy; Incredible Tech Solution Pune</p>
            </footer>