		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			<div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                         <li> <a href="dash.php" title="Master Register "> <h4> स्वागतकक्ष  </h4> </a> </li>
						 <li> <a href="local_billing.php" title="बिल तयार करा  "><h4> LOCAL बिले  </h4></a> </li>
						 <li> <a href="billing.php" title="बिल तयार करा  "><h4> VAT  बिले  </h4></a> </li>
						 <li> <a href="dash_stock.php"  title="स्टोक नोंदी पहा  "><h4>  स्टोक तपशील   </h4></a> </li>
                         <li> <a href="dash_customer.php" title=" ग्राहक तपशील "><h4>  ग्राहक तपशील </h4> </a> </li>
   			<!--			 <li> <a href="dash_purchase.php" title="खरेदी नोंदी  "><h4> खरेदी नोंद  </h4> </a></li>
						 <li> <a href="dash_supplier.php" title=" पुरवठादार "> <h4> पुरवठादार </h4> </a> </li> -->
                         </ul>
                </div>