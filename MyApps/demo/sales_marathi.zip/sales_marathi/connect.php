<?php 
mysql_select_db('incredib_bg_ahilyadevi',mysql_connect('localhost','incredib_bachatgat','bachatgat2016@incr'));
 date_default_timezone_set('Asia/Kolkata'); 

?>