<?php defined('SYSPATH') or die('No direct script access.');

/**
 * @package Cron
 *
 * @author      Chris Bandy
 * @copyright   (c) 2010 Chris Bandy
 * @license     http://www.opensource.org/licenses/isc-license.txt
 */
class Cron extends Kohana_Cron {}
