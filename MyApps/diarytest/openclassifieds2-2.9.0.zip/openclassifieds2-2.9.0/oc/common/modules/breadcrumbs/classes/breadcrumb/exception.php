<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * Breadcrumbs
 *
 * @author Kieran Graham
 */
class Breadcrumb_Exception extends Kohana_Exception
{
	
}