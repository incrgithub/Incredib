#  Open Classifieds Common


# Description
Common parts to Open Classifieds projects. Loaded as a module in /oc/modules/common.

In includes common helpers, tests, views (that belong to the system), vendors and modules. 

Without the module Common OC or OE won't work.

# License GPL v3
Please read [LICENSE](LICENSE)

# How to Contribute
Please read [CONTRIBUTING.md](CONTRIBUTING.md)