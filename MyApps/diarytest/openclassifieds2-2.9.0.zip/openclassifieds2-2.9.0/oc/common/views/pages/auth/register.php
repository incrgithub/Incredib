<?php defined('SYSPATH') or die('No direct script access.');?>

	
	<div class="page-header">
		<h1><?=_e('Register')?></h1>
	</div>

	<?=View::factory('pages/auth/register-form')?>
	  
