<?php defined('SYSPATH') or die('No direct script access.');?>
<div class="well">
	
	<div class="page-header">
		<h1><?=_e('Request Access')?></h1>
	</div>

	<?=View::factory('pages/auth/request-form')?>
	
</div><!--/well--> 
