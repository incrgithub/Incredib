<?php defined('SYSPATH') or die('No direct script access.');?>
<div class="well">
	
	<div class="page-header">
		<h1><?=_e('Remember password')?></h1>
	</div>

	<?=View::factory('pages/auth/forgot-form')?>
	
</div><!--/well--> 
