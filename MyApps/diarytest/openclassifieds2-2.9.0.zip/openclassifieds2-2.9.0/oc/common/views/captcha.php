<?php include('../oc/classes/captcha.php');
captcha::image($_GET['salt']);