<?php defined('SYSPATH') or die('No direct script access.');

/**
 * Securepay helper class
 *
 * @package    OC
 * @category   Payment
 * @author     Chema <chema@open-classifieds.com>
 * @copyright  (c) 2009-2016 Open Classifieds Team
 * @license    GPL v3
 */

class Securepay extends OC_Securepay{}