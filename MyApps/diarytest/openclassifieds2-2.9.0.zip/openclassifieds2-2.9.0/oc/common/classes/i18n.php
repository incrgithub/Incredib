<?php defined('SYSPATH') or die('No direct script access.');
/**
* I18n class for php-gettext
*
* @package    I18n
* @category   Translations
* @author     Chema <chema@open-classifieds.com>
* @copyright  (c) 2009-2014 Open Classifieds Team
* @license    GPL v3
*/
class I18n extends OC_I18n {}