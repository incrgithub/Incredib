<?php defined('SYSPATH') or die('No direct script access.');

class OC_Database_MySQLi extends Kohana_Database_MySQLi {}