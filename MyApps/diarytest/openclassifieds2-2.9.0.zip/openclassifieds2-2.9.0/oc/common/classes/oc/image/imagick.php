<?php defined('SYSPATH') OR die('No direct script access.');

class OC_Image_Imagick extends Kohana_Image_Imagick {}