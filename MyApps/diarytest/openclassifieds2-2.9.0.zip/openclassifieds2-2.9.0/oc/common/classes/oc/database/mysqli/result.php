<?php defined('SYSPATH') OR die('No direct script access.');
/**
 * MySQLi database result.   See [Results](/database/results) for usage and examples.
 *
 * @package    Kohana/Database
 * @category   Query/Result
 * @author     Kohana Team
 * @copyright  (c) 2008-2009 Kohana Team
 * @license    http://kohanaphp.com/license
 */
class OC_Database_MySQLi_Result extends Kohana_Database_MySQLi_Result {} // End Database_MySQLi_Result_Select