<?php defined('SYSPATH') OR die('No direct script access.');

class OC_Image_GD extends Kohana_Image_GD {}