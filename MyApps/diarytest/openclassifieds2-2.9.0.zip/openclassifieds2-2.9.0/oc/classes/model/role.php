<?php defined('SYSPATH') or die('No direct script access.');
/**
 * User Roles
 *
 * @author      Chema <chema@open-classifieds.com>
 * @package     Core
 * @copyright   (c) 2009-2014 Open Classifieds Team
 * @license     GPL v3
 */

class Model_Role extends Model_OC_Role {}