<?php defined('SYSPATH') OR die('No direct script access.');

class Image_GD extends OC_Image_GD {}
