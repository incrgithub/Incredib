<?php defined('SYSPATH') or die('No direct script access.');

class Database_MySQLi extends OC_Database_MySQLi {}