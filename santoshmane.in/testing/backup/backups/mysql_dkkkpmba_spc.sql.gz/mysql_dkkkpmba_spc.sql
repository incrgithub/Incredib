# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: dkkkpmba_spc
# Domain name: 
# (c)2017 
#
# Backup START time: 14:25:01
# Backup END time: 14:25:01
# Backup Date: 17 Feb 2017
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1487341501');
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487168701', '6025', '23');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487255102', '6025', '23');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486823102', '6025', '23');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486909502', '6025', '23');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1486995901', '6025', '23');
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1487082301', '6025', '23');
 
drop table if exists `tbl_enquiry`; 
CREATE TABLE `tbl_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('1', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'Hello');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('2', 'Kasturi', 'kasturi.bhalerao@gmail.com', '9970446416', 'I Love You Amtya');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('3', 'Amit Anil Bhalerao', 'amitbaramatimca@gmail.com', '8796154725', 'assssaa');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('4', 'Sunil Pawar', 'pawarsunil222@gmail.com', '8888330843', 'ok');
insert into `tbl_enquiry` (`id`, `name`, `email`, `contact`, `message`) values ('5', '', '', '', '');
 
drop table if exists `tbl_faculty`; 
CREATE TABLE `tbl_faculty` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `deptname` text NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('3', 'Teaching', 'Jamdade Dhanshri', 'Others', 'Principal', 'M.A.B.Ed', '3', 'Jamdade Dhanshri.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('4', 'Teaching', 'Jankar Kavita', 'Biology', 'Asst.Lecturer', 'M.Sc.B.Ed', '3', 'Jankar Kavita.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('5', 'Teaching', 'Dixit Madhuri', 'English', 'Asst.Lecturer', 'M.A.B.Ed', '4', 'Dixit Madhuri.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('6', 'Teaching', 'Mr. Nanaware Shrikant', 'Mathematics', 'Asst.Lecturer', 'M.Sc.B.Ed', '2', 'Mr. Nanaware Shrikant.jpg');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('7', 'Teaching', 'Mr.Bhise Vijay', 'Physics', 'Asst.Lecturer', 'MSc. B.ED', '1', 'Mr.Bhise Vijay.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('8', 'Teaching', 'Redekar Manisha', 'Chemistry', 'Asst.Lecturer', 'MSc. B.ED', '1', 'Redekar Manisha.png');
insert into `tbl_faculty` (`id`, `type`, `name`, `deptname`, `designation`, `qualification`, `experience`, `photo`) values ('9', 'Non-Teaching', 'Mr. Mohite P.M', 'Others', 'Peon', 'H.S.C', '1', 'Mr. Mohite P.M.png');
 
drop table if exists `tbl_gallery`; 
CREATE TABLE `tbl_gallery` (
  `photoid` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`photoid`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('52', 'physics.jpg', 'Physics Practicals');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('53', 'chemistry.jpg', 'Chemistry Practicals');
insert into `tbl_gallery` (`photoid`, `name`, `title`) values ('54', 'biology.jpg', 'Biology Practicals');
 
drop table if exists `tbl_login`; 
CREATE TABLE `tbl_login` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `tbl_login` (`member_id`, `UserName`, `Password`, `FirstName`, `LastName`) values ('1', 'lspsadmin', 'Phadtare12#$', 'Jayashri', 'Jamdade');
 
drop table if exists `tbl_news`; 
CREATE TABLE `tbl_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsdate` date NOT NULL,
  `subject` text NOT NULL,
  `description` text NOT NULL,
  `image` varchar(50) NOT NULL,
  `attachment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
